package myExceptions;
import java.io.*;
public class LSystemLengthException extends Exception{
	
	private int numChar;
	
	public LSystemLengthException(int nC) {
		
		numChar = nC;
	}
	public double getLength() {
		   return numChar;
	}
}
