package lsystems;

/**
 * 
 * A base class for L-System Rules. Each rule has a matching character
 * and an array of chars that should be produced when that match is found. 
 * 
 * @author tjkendon
 *
 */
public abstract class LRule {

	
	/**
	 * 
	 * Returns the character which this rules matches
	 * 
	 * @return the character the rule matches
	 */
	public abstract char getMatch();
	
	/**
	 * 
	 * Returns the array of characters produced by the rule
	 * 
	 * @return the array of characters produced
	 */
	public abstract char[] getBody();
	
		
		
	
	
}
class C_B extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'C';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'B'};
		return arry;
	}
}
class A_AB extends LRule{

	
	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	
	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'A','B'};
		return arry;
	}
}	
class B_A extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'B';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'A'};
		return arry;
	}
}
class A_A extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'A'};
		return arry;
	}
}
class A_AA extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'A','A'};
		return arry;
	}
}
class A_BC extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'B','C'};
		return arry;
	}
}
class A_Q extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {'Q'};
		return arry;
	}
}
class A_X extends LRule{

	public char getMatch() {
		// TODO Auto-generated method stub
		return 'A';
	}

	public char[] getBody() {
		// TODO Auto-generated method stub
		char[] arry = {};
		return arry;
	}
}