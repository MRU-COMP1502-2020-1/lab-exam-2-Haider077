package lsystems;

import java.util.*;

import myExceptions.LSystemLengthException;
import myExceptions.LSystemSymbolException;

public class LLine {

	
	char line[];
	Set<LRule> rules;
	
	public LLine (char[] start, Set<LRule> rules) {
		this.rules = rules;
		this.line = start;
	}
	
	public void process() throws LSystemLengthException, LSystemSymbolException {
		A_A r1 = new A_A();
		A_AA r2 = new A_AA();
		A_BC r3 = new A_BC();
		B_A r4 = new B_A();
		C_B r5 = new C_B();
		A_Q r6 = new A_Q();
		A_X r7 = new A_X();
		A_AB r8 = new A_AB();
		LRule rule[] = {r1,r2,r3,r4,r5,r6,r7,r8};
		for(int i = 0; i <= rule.length -1 ; i++) {
			if (rules.contains(rule[i])) {
			
			line = rule[i].getBody();
			 
			}
		}
		
	}
	
	
	
	

	private char[] listToArray(List<Character> list) {
		char[] newChars = new char[list.size()];
		for (int i = 0; i < list.size(); i++) {
			newChars[i] = list.get(i);
		}
		return newChars;
	}

	public String toString() {
		
		return new String(line);
	}
	
}
