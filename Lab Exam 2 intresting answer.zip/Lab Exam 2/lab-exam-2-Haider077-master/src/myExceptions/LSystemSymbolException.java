package myExceptions;
import java.io.*;
public class LSystemSymbolException extends Exception{
	
	private char symbol;
	public LSystemSymbolException(char sym) {
		symbol =sym;
	}
	public char getSymbol() {
		return symbol;
	}
}
